import { MessageSquare, Cpu, FileText } from "lucide-react";

const steps = [
  {
    number: "1",
    icon: MessageSquare,
    title: "Share Your Thoughts",
    description: "Type freely, upload text, or record your voice - express yourself naturally",
  },
  {
    number: "2",
    icon: Cpu,
    title: "AI Processes Your Data",
    description: "Advanced algorithms analyze linguistic patterns and psychological indicators",
  },
  {
    number: "3",
    icon: FileText,
    title: "Get Your Results",
    description: "Receive detailed insights, career suggestions, and a professional report",
  },
];

export const HowItWorks = () => {
  return (
    <section id="how-it-works" className="py-24 px-4 relative bg-card/20">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-4xl md:text-5xl font-bold text-center mb-16 bg-gradient-to-r from-accent via-primary to-accent bg-clip-text text-transparent">
          How It Works
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 relative">
          {/* Connection lines for desktop */}
          <div className="hidden md:block absolute top-16 left-1/4 right-1/4 h-0.5 bg-gradient-to-r from-primary/50 via-accent/50 to-primary/50" />
          
          {steps.map((step, index) => (
            <div 
              key={index}
              className="flex flex-col items-center text-center relative"
            >
              {/* Number badge */}
              <div className="mb-6 relative">
                <div className="w-16 h-16 rounded-full bg-primary flex items-center justify-center text-2xl font-bold shadow-[var(--glow-primary)] relative z-10">
                  {step.number}
                </div>
                <div className="absolute inset-0 rounded-full bg-primary/30 blur-xl animate-glow" />
              </div>

              {/* Icon */}
              <div className="mb-4 p-4 rounded-full bg-secondary">
                <step.icon className="w-8 h-8 text-accent" />
              </div>

              {/* Content */}
              <h3 className="text-xl font-semibold mb-3 text-foreground">
                {step.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
