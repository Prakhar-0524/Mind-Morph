import { Brain, Target, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: Brain,
    title: "AI-Powered Analysis",
    description: "Advanced NLP models decode your personality from text, voice, and behavioral patterns",
    color: "text-primary",
  },
  {
    icon: Target,
    title: "Big Five & MBTI",
    description: "Comprehensive assessment using scientifically validated personality frameworks",
    color: "text-accent",
  },
  {
    icon: TrendingUp,
    title: "Career Guidance",
    description: "Personalized career recommendations and development strategies based on your traits",
    color: "text-primary",
  },
];

export const Features = () => {
  return (
    <section id="features" className="py-24 px-4 relative">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="bg-card/50 backdrop-blur-sm border-border hover:border-primary/50 transition-all duration-300 hover:shadow-[0_0_30px_hsl(262_83%_58%/0.2)] group"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <CardContent className="p-8 text-center">
                <div className="mb-6 flex justify-center">
                  <div className={`p-4 rounded-full bg-secondary group-hover:bg-secondary/80 transition-all duration-300 ${feature.color}`}>
                    <feature.icon className="w-8 h-8" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-4 text-foreground">
                  {feature.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
