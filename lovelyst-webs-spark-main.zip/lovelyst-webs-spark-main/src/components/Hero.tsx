import { Button } from "@/components/ui/button";
import { Sparkles } from "lucide-react";
import brainIcon from "@/assets/brain-icon.png";

export const Hero = () => {
  return (
    <section id="hero" className="relative min-h-screen flex flex-col items-center justify-center px-4 overflow-hidden pt-16">
      {/* Gradient background effects */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/10 via-transparent to-transparent pointer-events-none" />
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-[120px] pointer-events-none" />
      
      <div className="relative z-10 text-center max-w-5xl mx-auto animate-fade-in">
        {/* Brain Icon */}
        <div className="mb-8 flex justify-center">
          <div className="relative animate-float">
            <img 
              src={brainIcon} 
              alt="AI Brain" 
              className="w-24 h-24 md:w-32 md:h-32"
            />
            <Sparkles className="absolute -top-2 -right-2 w-8 h-8 text-accent animate-glow" />
          </div>
        </div>

        {/* Main heading */}
        <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-primary via-primary to-accent bg-clip-text text-transparent">
          Mind Morph
        </h1>

        {/* Subtitle */}
        <p className="text-xl md:text-2xl text-muted-foreground mb-4 font-medium">
          AI Personality Analyzer
        </p>

        {/* Description */}
        <p className="text-base md:text-lg text-muted-foreground mb-12 max-w-2xl mx-auto leading-relaxed">
          Unlock the secrets of your personality through advanced AI analysis. 
          Discover your Big Five traits, MBTI type, and personalized career paths.
        </p>

        {/* CTA Button */}
        <Button 
          variant="hero" 
          size="lg" 
          className="text-base md:text-lg px-8 py-6 h-auto"
          onClick={() => window.location.href = '/assessment'}
        >
          Start Your Journey
          <Sparkles className="w-5 h-5" />
        </Button>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-muted-foreground/30 rounded-full flex justify-center pt-2">
          <div className="w-1 h-3 bg-muted-foreground/30 rounded-full" />
        </div>
      </div>
    </section>
  );
};
