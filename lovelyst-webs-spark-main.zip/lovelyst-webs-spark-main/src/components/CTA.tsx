import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

export const CTA = () => {
  return (
    <section className="py-24 px-4 relative">
      <div className="max-w-4xl mx-auto text-center">
        {/* Gradient background */}
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent pointer-events-none" />
        
        <div className="relative z-10">
          <h2 className="text-3xl md:text-5xl font-bold mb-6 text-foreground">
            Ready to Discover Yourself?
          </h2>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
            Join thousands who've unlocked their potential through AI-powered personality insights
          </p>

          <Button 
            variant="hero" 
            size="lg" 
            className="text-base md:text-lg px-8 py-6 h-auto group"
            onClick={() => window.location.href = '/assessment'}
          >
            Begin Assessment
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </div>
    </section>
  );
};
