import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Download, Share2, TrendingUp } from "lucide-react";
import { AnimatedBrain } from "@/components/AnimatedBrain";

interface PersonalityResults {
  bigFive: {
    openness: number;
    conscientiousness: number;
    extraversion: number;
    agreeableness: number;
    neuroticism: number;
  };
  mbti: string;
  summary: string;
  careers: string[];
  confidence: number;
}

const Results = () => {
  const [results, setResults] = useState<PersonalityResults | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const storedResults = sessionStorage.getItem("personalityResults");
    if (storedResults) {
      setResults(JSON.parse(storedResults));
    } else {
      navigate("/assessment");
    }
  }, [navigate]);

  if (!results) return null;

  const traitDescriptions: Record<string, { label: string; description: string }> = {
    openness: { 
      label: "Openness", 
      description: "Imagination, creativity, and openness to new experiences" 
    },
    conscientiousness: { 
      label: "Conscientiousness", 
      description: "Organization, dependability, and goal-directed behavior" 
    },
    extraversion: { 
      label: "Extraversion", 
      description: "Sociability, energy, and positive emotions" 
    },
    agreeableness: { 
      label: "Agreeableness", 
      description: "Compassion, cooperation, and trust" 
    },
    neuroticism: { 
      label: "Emotional Stability", 
      description: "Calmness and emotional resilience" 
    },
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Back Button */}
          <Button
            variant="ghost"
            onClick={() => navigate("/assessment")}
            className="mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            New Analysis
          </Button>

          {/* Header with 3D Brain */}
          <div className="text-center mb-12">
            <div className="h-[300px]">
              <AnimatedBrain />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-primary via-primary to-accent bg-clip-text text-transparent">
              Your Personality Profile
            </h1>
            <div className="flex items-center justify-center gap-4">
              <Badge variant="outline" className="text-lg py-2 px-4">
                MBTI: {results.mbti}
              </Badge>
              <Badge variant="secondary" className="text-lg py-2 px-4">
                Confidence: {results.confidence}%
              </Badge>
            </div>
          </div>

          {/* Summary */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" />
                Personality Summary
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-lg leading-relaxed text-muted-foreground">
                {results.summary}
              </p>
            </CardContent>
          </Card>

          {/* Big Five Traits */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Big Five Personality Traits (OCEAN)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {Object.entries(results.bigFive).map(([trait, score]) => {
                const inverted = trait === "neuroticism" ? 100 - score : score;
                return (
                  <div key={trait}>
                    <div className="flex justify-between items-center mb-2">
                      <div>
                        <h3 className="font-semibold text-foreground">
                          {traitDescriptions[trait].label}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {traitDescriptions[trait].description}
                        </p>
                      </div>
                      <span className="text-2xl font-bold text-primary">
                        {trait === "neuroticism" ? inverted : score}
                      </span>
                    </div>
                    <Progress value={inverted} className="h-3" />
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Career Recommendations */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Recommended Career Paths</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                {results.careers.map((career, index) => (
                  <Card key={index} className="bg-secondary/50">
                    <CardContent className="pt-6">
                      <div className="text-4xl mb-2">
                        {index === 0 ? "🎯" : index === 1 ? "💼" : "🚀"}
                      </div>
                      <h3 className="font-semibold text-lg">{career}</h3>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex flex-wrap gap-4 justify-center">
            <Button size="lg" variant="hero">
              <Download className="w-5 h-5" />
              Download Report
            </Button>
            <Button size="lg" variant="outline">
              <Share2 className="w-5 h-5" />
              Share Results
            </Button>
            <Button size="lg" variant="outline" onClick={() => navigate("/assessment")}>
              Take Another Assessment
            </Button>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Results;
