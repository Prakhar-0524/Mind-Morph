import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, MessageSquare, FileText, Mic } from "lucide-react";
import { AnimatedBrain } from "@/components/AnimatedBrain";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

const Assessment = () => {
  const [text, setText] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleAnalyze = async () => {
    if (!text.trim()) {
      toast({
        title: "Text Required",
        description: "Please enter some text to analyze",
        variant: "destructive",
      });
      return;
    }

    if (text.trim().length < 100) {
      toast({
        title: "More Text Needed",
        description: "Please provide at least 100 characters for accurate analysis",
        variant: "destructive",
      });
      return;
    }

    setIsAnalyzing(true);

    try {
      const { data, error } = await supabase.functions.invoke("analyze-personality", {
        body: { text },
      });

      if (error) throw error;

      // Store results in sessionStorage and navigate
      sessionStorage.setItem("personalityResults", JSON.stringify(data));
      navigate("/results");
    } catch (error: any) {
      console.error("Analysis error:", error);
      toast({
        title: "Analysis Failed",
        description: error.message || "Failed to analyze personality. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-16 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Hero Section with 3D Brain */}
          <div className="text-center mb-12">
            <AnimatedBrain />
            <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-primary via-primary to-accent bg-clip-text text-transparent">
              AI Personality Assessment
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Paste your WhatsApp chats, social media posts, or any text. Our AI analyzes your personality using Big Five and MBTI models.
            </p>
          </div>

          {/* Input Methods */}
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="border-primary/20 hover:border-primary/50 transition-colors">
              <CardHeader>
                <MessageSquare className="w-8 h-8 text-primary mb-2" />
                <CardTitle>WhatsApp Chats</CardTitle>
                <CardDescription>Paste exported chat conversations</CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-primary/20 hover:border-primary/50 transition-colors">
              <CardHeader>
                <FileText className="w-8 h-8 text-accent mb-2" />
                <CardTitle>Social Media</CardTitle>
                <CardDescription>Copy tweets, posts, or comments</CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-primary/20 hover:border-primary/50 transition-colors">
              <CardHeader>
                <Mic className="w-8 h-8 text-primary mb-2" />
                <CardTitle>Free Text</CardTitle>
                <CardDescription>Type or paste any text content</CardDescription>
              </CardHeader>
            </Card>
          </div>

          {/* Text Input */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Enter Your Text</CardTitle>
              <CardDescription>
                Paste WhatsApp chats, social media content, or any text (minimum 100 characters)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Example WhatsApp format:
[12/03/24, 10:30:25] John: Hey, how are you?
[12/03/24, 10:31:15] You: I'm doing great! Just finished a project...

Or just paste any text, tweets, posts, etc."
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="min-h-[300px] font-mono text-sm"
              />
              <div className="flex justify-between items-center mt-4">
                <span className="text-sm text-muted-foreground">
                  {text.length} characters {text.length >= 100 ? "✓" : `(need ${100 - text.length} more)`}
                </span>
                <Button
                  onClick={handleAnalyze}
                  disabled={isAnalyzing || text.length < 100}
                  size="lg"
                  variant="hero"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      Analyze Personality
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Info Cards */}
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-xl">Big Five (OCEAN)</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm text-muted-foreground">
                <p><strong>Openness:</strong> Creativity, curiosity, open-mindedness</p>
                <p><strong>Conscientiousness:</strong> Organization, responsibility, discipline</p>
                <p><strong>Extraversion:</strong> Sociability, energy, assertiveness</p>
                <p><strong>Agreeableness:</strong> Compassion, cooperation, trust</p>
                <p><strong>Neuroticism:</strong> Emotional stability, stress response</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-xl">MBTI Types</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p className="mb-2">16 personality types based on:</p>
                <p>• Introversion (I) vs Extraversion (E)</p>
                <p>• Sensing (S) vs Intuition (N)</p>
                <p>• Thinking (T) vs Feeling (F)</p>
                <p>• Judging (J) vs Perceiving (P)</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Assessment;
